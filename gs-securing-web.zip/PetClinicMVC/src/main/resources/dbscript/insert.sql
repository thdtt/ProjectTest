INSERT INTO pettype(id,name,version) VALUES (1, 'cat', 1);
INSERT INTO pettype(id,name,version) VALUES (2, 'dog', 1);
INSERT INTO pettype(id,name,version) VALUES (3, 'lizard', 1);
INSERT INTO pettype(id,name,version) VALUES (4, 'snake', 1);
INSERT INTO pettype(id,name,version) VALUES (5, 'bird', 1);
INSERT INTO pettype(id,name,version) VALUES (6, 'hamster', 1);

INSERT INTO treatmenttype(id,name,version) VALUES (1, 'Food & Drink', 1);
INSERT INTO treatmenttype(id,name,version) VALUES (2, 'Bath', 1);
INSERT INTO treatmenttype(id,name,version) VALUES (3, 'Manicure', 1);
INSERT INTO treatmenttype(id,name,version) VALUES (4, 'Pedicure', 1);
INSERT INTO treatmenttype(id,name,version) VALUES (5, 'Massage', 1);
INSERT INTO treatmenttype(id,name,version) VALUES (6, 'Creambath', 1);