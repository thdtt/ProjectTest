package org.sofyan.latihan.app.ctrl.message;

public interface MessageConstant {
	
	final boolean SUCCESS = true;
	final boolean FAIL = false;

}

