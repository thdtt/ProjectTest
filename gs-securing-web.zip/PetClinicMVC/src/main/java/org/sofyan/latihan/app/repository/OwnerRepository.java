package org.sofyan.latihan.app.repository;

import org.sofyan.latihan.app.model.Owner;

public interface OwnerRepository extends BaseRepository<Owner, Long> {

}
