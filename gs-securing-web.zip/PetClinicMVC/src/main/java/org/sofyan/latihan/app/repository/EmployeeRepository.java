package org.sofyan.latihan.app.repository;

import org.sofyan.latihan.app.model.Employee;

public interface EmployeeRepository extends BaseRepository<Employee, Long> {

}
