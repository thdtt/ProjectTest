package org.sofyan.latihan.app.bean;

public class OwnerSearchBean extends SearchBean {

	
	
}
