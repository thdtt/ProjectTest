package org.sofyan.latihan.app.repository;

import org.sofyan.latihan.app.model.PetType;

public interface PetTypeRepository extends BaseRepository<PetType, Long> {

}
