package org.sofyan.latihan.app.model;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="pettype")
public class PetType extends NamedEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
}
