package org.sofyan.latihan.app.service;

import org.sofyan.latihan.app.model.Owner;

public interface OwnerService extends BaseService<Owner, Long>{

}
