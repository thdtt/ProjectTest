package org.sofyan.latihan.app.repository;

import org.sofyan.latihan.app.model.TreatmentType;

public interface TreatmentTypeRepository extends BaseRepository<TreatmentType, Long> {
	
}
