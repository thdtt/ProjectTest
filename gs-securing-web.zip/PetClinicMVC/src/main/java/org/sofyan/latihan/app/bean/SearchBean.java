package org.sofyan.latihan.app.bean;

public abstract class SearchBean extends DataTableRequestBean {
	
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
