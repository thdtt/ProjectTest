package com.petclinic.spring.services;


import com.petclinic.spring.model.Vet;

/*
 *Created by olga on 15.04.2020
 */
public interface VetService extends CrudService<Vet, Long> {

}
