package com.petclinic.spring.services;


import com.petclinic.spring.model.Speciality;

/*
 *Created by olga on 19.04.2020
 */
public interface SpecialityService extends CrudService<Speciality, Long> {
}
