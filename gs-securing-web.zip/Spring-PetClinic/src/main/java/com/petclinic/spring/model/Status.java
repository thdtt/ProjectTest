package com.petclinic.spring.model;

/*
 *Created by olga on 10.09.2020
 */
public enum Status {
    ACTIVE, NOT_ACTIVE, DELETED
}
