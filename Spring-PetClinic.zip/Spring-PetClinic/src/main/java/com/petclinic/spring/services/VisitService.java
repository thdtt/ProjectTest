package com.petclinic.spring.services;


import com.petclinic.spring.model.Visit;

/*
 *Created by olga on 22.04.2020
 */
public interface VisitService extends CrudService<Visit, Long> {
}
