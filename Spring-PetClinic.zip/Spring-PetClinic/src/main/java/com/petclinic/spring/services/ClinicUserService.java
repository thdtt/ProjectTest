package com.petclinic.spring.services;

/*
 *Created by olga on 13.09.2020
 */
//public interface ClinicUserService extends CrudService<User, Long> {
//    User findByUsername(String username);
//}
