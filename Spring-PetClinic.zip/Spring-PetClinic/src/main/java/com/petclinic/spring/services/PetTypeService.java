package com.petclinic.spring.services;


import com.petclinic.spring.model.PetType;

/*
 *Created by olga on 17.04.2020
 */
public interface PetTypeService extends CrudService<PetType, Long> {
}
