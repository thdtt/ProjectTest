package com.example.sbsocial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSocialJpaApplicationTests {

    @Test
    void contextLoads() {
    }

}
