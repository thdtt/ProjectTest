package opencart.Repository;

public interface OrderDetailRepository {
}
