package opencart.Service.ServiceImpl;

import opencart.Service.ServiceInt.SearchService;
import org.springframework.stereotype.Service;

@Service
public class SearchServiceImpl implements SearchService {
}
