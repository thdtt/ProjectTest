package opencart.Service.ServiceInt;

public interface SearchService {
}
